<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
   
</head>

<?php
$servername = "localhost";
$database = "test1";
$username = "ennio";
$password = "";


$inserted =0;
$updated = 0;
$deleted = 0; 


setLocale(LC_ALL, 'ru_RU.cp1251');


try {
       
    $dsn = "mysql:host=$servername;dbname=$database;charset=utf8";
    $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $conn = new PDO($dsn, $username, $password, $opt);
//    echo "Connected successfully";
    }

catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }


        // Show database table workers
        // check if empty table

            $stmt = $conn->prepare("SELECT uid,firstName, lastName, birthDay, dateChange, description FROM workers");
            $stmt->execute();
            $dataworkers = $stmt->fetchAll();
            
            if (count($dataworkers) > 0)
                   {
                    
                  //  echo "<br>Table is not empty<br>"; 
                  //  echo  "table has: ". count($dataworkers)." elements"; 
                    $empty_table = false;   
                   }
                   else 
                   {
                   // echo "<br>Table is empty<br>"; 
                    $empty_table = true;     
                   }
           

           echo "<table style ='margin:15px 5px;'>";
            foreach ($dataworkers as $row) {
                echo "<tr>";
                echo "<td style='padding:2px 10px'>".$row['uid']."</td><td>".$row['firstName']."</td><td>".$row['lastName']."</td><td>".$row['birthDay']."</td><td>".$row['dateChange']."</td><td>".$row['description']."</td>";
                echo "</tr>";
            }
            echo "</table>"
 
?>

<?php
  
   $csvdata=array();
    
 // import CSV

    if(isset($_POST["submit"]))    
    {

        $uploaddir = '/uploads';
     
      if(isset($_FILES) && $_FILES['fname']['error'] == 0)
        { 
            $destiation_dir = dirname(__FILE__) .$uploaddir.'/'.$_FILES['fname']['name']; 
            
            move_uploaded_file($_FILES['fname']['tmp_name'], $destiation_dir ); 
        
             }
        else
            {
                echo 'No File Uploaded'; 
            } 
                   
       
        $handle = fopen($destiation_dir, "r") or die("Error opening file !");
        
        $row = 1;
        while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) 
        {
            $num = count($data);
           
            $row++;
            
            $birthDay = explode(".",$data[3]);    
            $birthDaydate = $birthDay[2]."-".$birthDay[1]."-".$birthDay[0];
            $dateChange = explode(".",$data[4]);    
            $dateChangedate = $dateChange[2]."-".$dateChange[1]."-".$dateChange[0];

            $csvdata[]=array('uid'=>$data[0],'firstName'=>$data[1],'lastName'=>$data[2],'birthDay'=>$birthDaydate,'dateChange'=>$dateChangedate,'description'=>$data[5],'found'=>0);
           
                      
        }

        fclose($handle);

         //Updating database
                 
    }
          // if table is not empty update data
          if (($empty_table==false) and (count($csvdata)>0))
            {
                   
                foreach ($dataworkers as $workersrow) {
                   
                    $found = 0;
                   
                         
                    foreach ($csvdata as  $csvrow) 
                    {
                        if (($workersrow['uid'] == $csvrow['uid'])) 
                        {
                            $found = 1;
                            $csvrow['found']=1;

                            // if 'dateChange' different in CSV - update data in table 'workers'
                           if ($workersrow['dateChange']<>$csvrow['dateChange']) 
                             {
                                 
                                 //$tobeupdated[] = $workersrow['uid'];
         
                                  $stmt = $conn->prepare("UPDATE workers SET firstName = ?, lastName=?, birthDay=?, dateChange=?,description=? WHERE uid=?");
                                  $stmt->execute(array($csvrow['firstName'], $csvrow['lastName'], $csvrow['birthDay'],$csvrow['dateChange'],$csvrow['description'],$workersrow['uid']));   
                                 ++$updated;     
                             }
                      
                         }
                    }
         
                    // if element exists in the table and not found in the CSV
                    // and the table is not empty - delete element from the database
         
                    if (($found == 0)) 
                          {
                             //$tobedeleted[]=$workersrow['uid']; 
                            
         
                             $sql = "DELETE FROM workers WHERE uid = ?";
                             $stmt = $conn->prepare($sql);
                             $stmt->execute(array($workersrow['uid']));
                             ++$deleted;
                          }  
         
                                     
                 }
                
            }




     
            // if table is empty insert the data from CSV
         
            if (($empty_table==true) and (count($csvdata)>0)) 
               {
                
            foreach($csvdata as $value)
                    { 
                        if ($value['found']==0) 
                          {
                          echo $value['uid']." ".$value['firstName']." ".$value['lastName']." ".$value['found']."<br>";
                          $stmt = $conn->prepare("INSERT INTO workers (firstName, lastName, birthDay,dateChange,description) VALUES (?, ?, ?, ?, ?)");
                          $stmt->execute(array($value['firstName'],$value['lastName'],$value['birthDay'],$value['dateChange'],$value['description']));     
                          ++$inserted;
                          }      
                    } 
          
                }

          echo "<div style='border:1px solid blue; padding:10px;width:300px;margin:20px 5px;'>";
          echo "<br>";
          echo "Inserted: ".$inserted."<br>";
          echo "Updated: ".$updated."<br>";
          echo "Deleted: ".$deleted."<br>";
          echo "</div>";    


?>


<?php // Display form ?>

<body>
    <div style="border:1px solid black; padding: 10px;width:300px">
    <p>Upload *.csv file in the following format</p>
    <p>uid, firstName, lastName, birthDay, dateChange, description.</p>
</div>
    <br>
    <form method="post" enctype="multipart/form-data">
    <input type="file" name="fname">
    <br><br>
    <button type="submit" name="submit">Submit</button>
    </form>
</body>
</html>